package io.mo.glassmic.ui.settings

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import io.mo.glassmic.service.WaveformOverlayService
import io.mo.glassmic.data.audio.FloatingIconStore
import io.mo.glassmic.data.config.ConfigStore
import io.mo.glassmic.data.runtime.AudioStatsRepository
import io.mo.glassmic.data.runtime.HookStatus
import io.mo.glassmic.data.runtime.HookStatusRepository
import io.mo.glassmic.data.runtime.VisibilityCompatRepository
import kotlinx.coroutines.flow.asStateFlow
import io.mo.glassmic.log.GlassLog
import io.mo.glassmic.data.config.AppLocale
import io.mo.glassmic.proto.AppConfig
import io.mo.glassmic.proto.AppLanguage
import io.mo.glassmic.proto.FloatingSize
import io.mo.glassmic.proto.PlaybackPolicy
import io.mo.glassmic.proto.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val config: AppConfig = AppConfig.getDefaultInstance(),
    val hook: HookStatus = HookStatus(
        activity = io.mo.glassmic.data.runtime.HookActivity.NEVER_PINGED,
        lastPingMs = 0L,
        lastPackage = null,
        api = 0
    ),
    val interceptReads: Long = 0L,
    val interceptBytes: Long = 0L,
    val interceptLastMs: Long = 0L,
    val interceptLastPkg: String? = null,
    val interceptLastSr: Int = 0,
    val interceptLastCh: Int = 0
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val configStore: ConfigStore,
    private val floatingIconStore: FloatingIconStore,
    private val audioStatsRepo: AudioStatsRepository,
    private val visibilityCompatRepo: VisibilityCompatRepository,
    hookStatusRepo: HookStatusRepository
) : ViewModel() {

    private val _visibilityCompat = MutableStateFlow(visibilityCompatRepo.isEnabled())
    /** 「严格 ROM 兼容」开关状态，UI 单独 collect。 */
    val visibilityCompat: StateFlow<Boolean> = _visibilityCompat.asStateFlow()

    /** 每次进入设置页时按系统属性真实值刷新开关（属性非 1 一律显示关闭）。 */
    fun refreshVisibilityCompat() {
        _visibilityCompat.value = visibilityCompatRepo.isEnabled()
    }

    private val _iconError = MutableStateFlow<String?>(null)
    /** 悬浮球图标导入错误，UI 单独 collect 弹提示。 */
    val iconError: StateFlow<String?> = _iconError.asStateFlow()

    fun setVisibilityCompat(enabled: Boolean) {
        _visibilityCompat.value = enabled  // 立即回显
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val ok = visibilityCompatRepo.setEnabled(enabled)
            // 开启时若 Root 写入失败（多半是未授权 su），回滚开关让用户察觉。
            if (enabled && !ok) _visibilityCompat.value = false
        }
    }

    val state: StateFlow<SettingsUiState> = combine(
        configStore.flow, hookStatusRepo.flow, audioStatsRepo.flow
    ) { cfg, hook, stats ->
        SettingsUiState(
            config = cfg,
            hook = hook,
            interceptReads = stats.totalReads,
            interceptBytes = stats.totalBytes,
            interceptLastMs = stats.lastInterceptMs,
            interceptLastPkg = stats.lastPackage,
            interceptLastSr = stats.lastSampleRate,
            interceptLastCh = stats.lastChannels
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, SettingsUiState())

    // ============ 外观 ============
    fun setTheme(theme: ThemeMode) = viewModelScope.launch {
        configStore.update { it.setAppearance(it.appearance.toBuilder().setTheme(theme)) }
    }

    fun setGlassEffect(enabled: Boolean) = viewModelScope.launch {
        configStore.update { it.setAppearance(it.appearance.toBuilder().setGlassEffect(enabled)) }
    }

    fun setReduceMotion(reduce: Boolean) = viewModelScope.launch {
        configStore.update { it.setAppearance(it.appearance.toBuilder().setReduceMotion(reduce)) }
    }

    fun setLanguage(language: AppLanguage) {
        // 同步执行：调用方（设置页）选完语言后会立即 recreate() 让改动马上生效，
        // 必须保证 SharedPreferences 缓存 + AppCompatDelegate 的语言在 recreate() 之前就已写入，
        // 否则会因为协程还没跑到这里而导致第一次点击"没反应"，要点第二次才生效。
        AppLocale.apply(context, language)
        viewModelScope.launch {
            configStore.update {
                it.setAppearance(it.appearance.toBuilder().setLanguage(language).setLanguageResolved(true))
            }
        }
    }

    // ============ 悬浮窗 ============
    fun setFloatingEnabled(enabled: Boolean) = viewModelScope.launch {
        configStore.update { it.setFloatingWindow(it.floatingWindow.toBuilder().setEnabled(enabled)) }
    }

    fun setFloatingOpacity(opacity: Float) = viewModelScope.launch {
        configStore.update {
            it.setFloatingWindow(it.floatingWindow.toBuilder().setOpacity(opacity.coerceIn(0.2f, 1f)))
        }
    }

    fun setFloatingSize(size: FloatingSize) = viewModelScope.launch {
        configStore.update { it.setFloatingWindow(it.floatingWindow.toBuilder().setSize(size)) }
    }

    /** 导入自定义悬浮球图标：复制到私有目录并持久化相对路径。传 null 表示清除，回退默认图标。 */
    fun setFloatingIcon(uri: Uri?) = viewModelScope.launch {
        val relPath = if (uri == null) "" else floatingIconStore.importIcon(uri) ?: run {
            _iconError.value = "图标导入失败"
            return@launch
        }
        configStore.update { it.setFloatingWindow(it.floatingWindow.toBuilder().setCustomIconPath(relPath)) }
    }

    fun consumeIconError() { _iconError.value = null }

    // ============ 实时波形悬浮窗 ============
    fun setWaveformEnabled(enabled: Boolean) = viewModelScope.launch {
        configStore.update {
            it.setFloatingWindow(it.floatingWindow.toBuilder().setWaveformEnabled(enabled))
        }
        if (enabled) WaveformOverlayService.start(context) else WaveformOverlayService.stop(context)
    }

    fun setWaveformOpacity(opacity: Float) = viewModelScope.launch {
        configStore.update {
            it.setFloatingWindow(it.floatingWindow.toBuilder().setWaveformOpacity(opacity.coerceIn(0.15f, 1f)))
        }
    }

    // ============ 快捷操作 ============
    /**
     * 音量键双击快捷操作。开关只写配置——实际布防由悬浮窗服务在运行期间同步给 Xposed 侧，
     * 悬浮窗没开时这里打开也不会拦任何按键。
     */
    fun setVolumeKeysEnabled(enabled: Boolean) = viewModelScope.launch {
        configStore.update { it.setShortcuts(it.shortcuts.toBuilder().setVolumeKeysEnabled(enabled)) }
    }

    // ============ 实时耳返 / 音频监听 ============
    fun setAudioMonitorEnabled(enabled: Boolean) = viewModelScope.launch {
        configStore.update {
            val cur = it.audioMonitor
            it.setAudioMonitor(cur.toBuilder().setEnabled(enabled))
        }
    }

    fun setAudioMonitorVolume(volume: Float) = viewModelScope.launch {
        configStore.update {
            val cur = it.audioMonitor
            it.setAudioMonitor(cur.toBuilder().setVolume(volume.coerceIn(0f, 1f)))
        }
    }

    // ============ 默认播放策略 ============
    fun setPolicy(policy: PlaybackPolicy) = viewModelScope.launch {
        configStore.update { it.setPlaybackPolicy(policy) }
    }

    // ============ 实验功能 ============
    fun setExperimentalUnlocked(unlocked: Boolean) = viewModelScope.launch {
        configStore.update { it.setExperimental(it.experimental.toBuilder().setUnlocked(unlocked)) }
    }

    fun setStressTest(v: Boolean) = viewModelScope.launch {
        configStore.update { it.setExperimental(it.experimental.toBuilder().setStressTest(v)) }
    }

    fun setHighGain(v: Boolean) = viewModelScope.launch {
        configStore.update { it.setExperimental(it.experimental.toBuilder().setHighGain(v)) }
    }

    fun setNoiseSim(v: Boolean) = viewModelScope.launch {
        configStore.update { it.setExperimental(it.experimental.toBuilder().setNoiseSim(v)) }
    }

    fun setLimiter(v: Boolean) = viewModelScope.launch {
        configStore.update { it.setExperimental(it.experimental.toBuilder().setLimiterEnabled(v)) }
    }

    fun setReverbEnabled(v: Boolean) = viewModelScope.launch {
        configStore.update { it.setExperimental(it.experimental.toBuilder().setReverbEnabled(v)) }
    }

    fun setReverbAmount(v: Float) = viewModelScope.launch {
        configStore.update {
            it.setExperimental(it.experimental.toBuilder().setReverbAmount(v.coerceIn(0f, 1f)))
        }
    }

    fun setSpeedEnabled(v: Boolean) = viewModelScope.launch {
        configStore.update { it.setExperimental(it.experimental.toBuilder().setSpeedEnabled(v)) }
    }

    fun setSpeedFactor(v: Float) = viewModelScope.launch {
        configStore.update {
            it.setExperimental(it.experimental.toBuilder().setSpeedFactor(v.coerceIn(0.5f, 2.0f)))
        }
    }
}
